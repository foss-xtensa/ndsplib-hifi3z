/*
  NatureDSP Signal Processing Library. IIR part
    Lattice Block Real IIR, floating point
    C code optimized for HiFi3

    M=2
  IntegrIT, 2006-2018
*/
#include "latrf_common.h"
#include "common_fpu.h"

#if (HAVE_VFPU || HAVE_FPU)
void latrf_process2(struct tag_latrf_t *latr, 
                    float32_t * restrict     r,
                    const float32_t*         x, int N )
{
    float32_t d0,d1,c0,c1;
          float32_t * restrict delLine;
    const float32_t * restrict coef;

    float32_t t0;
    float32_t scale;

    int n;

    NASSERT(latr->M==2);
    delLine = latr->delayLine;
    coef    = latr->coef;
    scale   = latr->scale;
    d0=delLine[0];
    d1=delLine[1];
    c0=coef[0];
    c1=coef[1];

    for ( n=0; n<N; n++ )
    {
        t0 = x[n]*scale;
        t0 -= d1 * c1;
        t0 -= d0 * c0;
        d1 = d0 + t0 * c0;
        d0 = t0;
        r[n] = t0;
    }
    delLine[0]=d0;
    delLine[1]=d1;
} // latrf2_process()
#endif
