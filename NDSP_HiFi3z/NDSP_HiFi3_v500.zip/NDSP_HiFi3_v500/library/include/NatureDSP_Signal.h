#ifndef __NATUREDSP_SIGNAL_H__
#define __NATUREDSP_SIGNAL_H__

#include "NatureDSP_types.h"

/* FIR Filters and Related Functions */
#include "NatureDSP_Signal_fir.h"
/* IIR Filters */
#include "NatureDSP_Signal_iir.h"
/* FFT Routines */
#include "NatureDSP_Signal_fft.h"
/* Matrix Operations */
#include "NatureDSP_Signal_matop.h"
/* Matrix Decomposition and Inversion Functions */
#include "NatureDSP_Signal_matinv.h"
/* Vector Operations */
#include "NatureDSP_Signal_vector.h"
/* Math Functions */
#include "NatureDSP_Signal_math.h"
/* Complex Math Functions */
#include "NatureDSP_Signal_complex.h"
/* Fitting and Interpolation Routines */
#include "NatureDSP_Signal_fit.h"
/* library identification */
#include "NatureDSP_Signal_id.h"

#endif/* __NATUREDSP_SIGNAL_H__ */
