/*
	NaN values for single precision routines
*/

/* Portable data types. */
#include "NatureDSP_types.h"
/* Common utility macros. */
#include "common.h"
/* NaN values for single precision routines. */
#include "nanf_tbl.h"

const union ufloat32uint32 sNaNf       = { 0x7f800001 }; /* Signalling NaN          */
const union ufloat32uint32 qNaNf       = { 0x7fc00000 }; /* Quiet NaN               */
const union ufloat32uint32 minus_sNaNf = { 0xff800001 }; /* Negative Signalling NaN */
const union ufloat32uint32 minus_qNaNf = { 0xffc00000 }; /* Negative Quiet NaN      */
