/*
    tables for alog10f(x) approximation
*/
#include "NatureDSP_types.h"
#include "alog10f_tbl.h"
#include "common.h"


const union ufloat32uint32 alog10fminmax[2]=  /* minimum and maximum arguments of alog10f() input */
{
    {0xc23369f4}, /*-44.853470    */
    {0x421a209b}  /*38.5318412781 */
};

const int32_t invlog10_2_Q29=1783446566L;  /* 1/log10(2), Q29 */
