#include "vec_alog_table.h"
#include "common.h"


/* polynomial coefficients for 2^x, in range -1...0 */
const int32_t pow2poly[]={14685058,114217091,514075394,1488269031,2147475316};
