
/*
    1/(2*pi) constant
*/

#include "NatureDSP_types.h"
#include "inv2pif_tbl.h"

const int64_t inv2pif_Q53 = {0x517cc1b727220c00LL>>10}; /* 1/(2pi) in Q53 */
const union ufloat32uint32 inv4pif={0x3fa2f983}; /* 4/pi */
const union ufloat32uint32 inv2pif = { 0x3f22f983 }; /* 2/pi */
