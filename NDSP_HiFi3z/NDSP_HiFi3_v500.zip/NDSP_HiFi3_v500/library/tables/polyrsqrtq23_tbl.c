#include "polyrsqrtq23_tbl.h"

/* 
        first approximation of 0.03125/sqrt(x)
        polynomial coefficients:
        x=(0.25:pow2(1,-15):1);
        y=pow2(1./sqrt(x),-5);
        p=polyfit(x,y,4);
*/
const int32_t polyrsqrtq23[]={954699, -3000477, 3687496, -2284416, 905920};

