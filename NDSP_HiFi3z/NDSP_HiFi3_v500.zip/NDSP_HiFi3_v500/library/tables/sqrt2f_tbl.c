
/*
    sqrt(2) and sqrt(0.5) constants for single precision routines
*/
#include "NatureDSP_types.h"
#include "common.h"
#include "sqrt2f_tbl.h"

const union ufloat32uint32 sqrt2f  ={0x3fb504f3}; /* sqrt(2)   */
const union ufloat32uint32 sqrt0_5f={0x3f3504f3}; /* sqrt(0.5) */
