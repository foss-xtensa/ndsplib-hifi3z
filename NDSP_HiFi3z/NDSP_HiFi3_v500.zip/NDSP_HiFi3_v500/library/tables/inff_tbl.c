
/*
    infinities for single precision routines
*/

#include "NatureDSP_types.h"
#include "inff_tbl.h"

const union ufloat32uint32 minusInff ={0xff800000}; /* -Inf */
const union ufloat32uint32 plusInff  ={0x7f800000}; /* +Inf */
const union ufloat32uint32 realmaxf  ={0x7f7fffff}; /* maximum floating point number */
