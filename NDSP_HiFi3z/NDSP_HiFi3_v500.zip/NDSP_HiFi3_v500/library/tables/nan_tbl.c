/*
	NaN values for double precision routines
*/

/* Portable data types. */
#include "NatureDSP_types.h"
/* Common utility macros. */
#include "common.h"
/* NaN values for double precision routines. */
#include "nan_tbl.h"

const union ufloat64uint64 sNaN       = { 0x7ff0000000000001ULL }; /* Signalling NaN          */
const union ufloat64uint64 qNaN       = { 0x7ff8000000000000ULL }; /* Quiet NaN               */
const union ufloat64uint64 minus_sNaN = { 0xfff0000000000001ULL }; /* Negative Signalling NaN */
const union ufloat64uint64 minus_qNaN = { 0xfff8000000000000ULL }; /* Negative Quiet NaN      */
