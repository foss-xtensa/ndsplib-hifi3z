/*
    tables for alog2f(x) approximation
*/
#include "NatureDSP_types.h"
#include "alog2f_tbl.h"
#include "common.h"


const union ufloat32uint32 alog2fminmax[2]=  /* minimum and maximum arguments of alog2f() input */
{
    {0xc3150000}, /*-149 */
    {0x43000000}  /* 128 */
};
