
/*
    pi constants for single precision routines
*/

#include "NatureDSP_types.h"
#include "pif_tbl.h"

const union ufloat32uint32 pif ={0x40490fdb}; /* pi */
const union ufloat32uint32 pi2f={0x3fc90fdb}; /* pi/2 */
const union ufloat32uint32 pi4f={0x3f490fdb}; /* pi/4 */
const union ufloat32uint32  pi2m1f={0x3f121fb5};  /* pi/2-1 */
