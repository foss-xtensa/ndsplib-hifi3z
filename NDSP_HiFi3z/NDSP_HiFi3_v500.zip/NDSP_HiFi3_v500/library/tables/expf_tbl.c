
/*
    tables for expf(x) approximation
*/
#include "NatureDSP_types.h"
#include "expf_tbl.h"
#include "common.h"

/* 
   polynomial coefficients for 2^x in range 0...1

   derived by MATLAB code:
   order=6;
   x=(0:pow2(1,-16):1);
   y=2.^x;
   p=polyfit(x,y,order);
   p(order+1)=1;
   p(order)=p(order)-(sum(p)-2);
*/
const int32_t ALIGN(16) expftbl_Q30[8]=
{    234841,
    1329551,
   10400465,
   59570027,
  257946177,
  744260763,
 1073741824,
 0 /* Padding to allow for vector loads */
};

const union ufloat32uint32 expfminmax[2]=  /* minimum and maximum arguments of expf() input */
{
  {0xc2ce8ed0},  /*-1.0327893066e+002f */
  {0x42b17218}   /* 8.8722839355e+001f */
};

const int32_t invln2_Q30=1549082005L; /* 1/ln(2), Q30 */
