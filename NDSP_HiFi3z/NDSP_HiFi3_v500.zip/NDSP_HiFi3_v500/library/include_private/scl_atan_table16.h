
#ifndef INTEGRIT_SCL_ATAN_TABLE16_H
#define INTEGRIT_SCL_ATAN_TABLE16_H
#include "NatureDSP_types.h"

extern const int32_t atan_table16[];

#endif /* INTEGRIT_SCL_ATAN_TABLE16_H */
