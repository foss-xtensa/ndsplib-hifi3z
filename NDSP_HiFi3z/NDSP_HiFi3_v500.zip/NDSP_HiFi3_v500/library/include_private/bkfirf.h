#ifndef BKFIRF_H__
#define BKFIRF_H__
/*
  NatureDSP Signal Processing Library. FIR part
    Real block FIR filter, floating point
  IntegrIT, 2006-2017
*/
#include "NatureDSP_types.h"

/* Filter instance structure. */
typedef struct tag_bkfirf_t
{
  int               M; /* Filter length                   */
  const float32_t * h; /* Filter coefficients             */
        float32_t * d; /* Delay line of length M          */
        float32_t * p; /* Pointer into the delay line     */
} bkfirf_t, *bkfirf_ptr_t;

#endif /* BKFIRF_H__ */
