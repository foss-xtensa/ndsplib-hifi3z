
/*
	Infinities for single precision routines
*/
#ifndef INFF_H__
#define INFF_H__

#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 minusInff; /* -Inf */
externC const union ufloat32uint32 plusInff ; /* +Inf */
externC const union ufloat32uint32 realmaxf ; /* maximum floating point number */

#endif /* INFF_H__ */
