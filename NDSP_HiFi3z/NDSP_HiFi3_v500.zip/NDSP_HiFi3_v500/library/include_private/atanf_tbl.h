
/*
    tables for atanf(x) approximation
*/
#ifndef ATANFTBL_H__
#define ATANFTBL_H__

#include "NatureDSP_types.h"
#include "common.h"

#define ATANF_ALG 0     /* 0 - 2 ULP code, 1 - 1 ULP code */

externC const union ufloat32uint32 atanftbl1[8]; 
externC const union ufloat32uint32 atanftbl2[8]; 

#if ATANF_ALG==0
#elif ATANF_ALG==1
externC const union ufloat32uint32 atanftbl1a[8]; 
externC const union ufloat32uint32 atanftbl2a[8]; 
#else
#error wrong ATANF_ALG
#endif

#endif /* ATANFTBL_H__ */
