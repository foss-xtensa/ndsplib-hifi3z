/*
	NaN values for single precision routines
*/

#ifndef __NANF_TBL_H
#define __NANF_TBL_H

/* Portable data types. */
#include "NatureDSP_types.h"
/* Common utility macros. */
#include "common.h"

externC const union ufloat32uint32 sNaNf;       /* Signalling NaN          */
externC const union ufloat32uint32 qNaNf;       /* Quiet NaN               */
externC const union ufloat32uint32 minus_sNaNf; /* Negative Signalling NaN */
externC const union ufloat32uint32 minus_qNaNf; /* Negative Quiet NaN      */

#endif /* __NANF_TBL_H */
