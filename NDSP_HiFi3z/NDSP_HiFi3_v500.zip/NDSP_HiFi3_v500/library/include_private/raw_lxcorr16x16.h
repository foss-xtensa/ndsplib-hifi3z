#ifndef RAW_LCORR16X16_H__
#define RAW_LCORR16X16_H__
#include "NatureDSP_types.h"

/*-----------------------------------------------------
raw linear correlation:
Input:
x[N] padded with extra 6 zeroes
y[M] padded with extra 4 zeroes
Output:
r[N+M-1]
restrictions:
M should be >0
x,y aligned on 8-byte boundary
-----------------------------------------------------*/
void raw_lxcorr16x16(int16_t * r, const int16_t * restrict x, const int16_t * restrict y, int N, int M);

#endif
