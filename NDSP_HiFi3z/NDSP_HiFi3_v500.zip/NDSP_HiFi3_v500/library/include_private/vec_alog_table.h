
#ifndef INTEGRIT_VEC_LOG_TABLE_H
#define INTEGRIT_VEC_LOG_TABLE_H
#include "NatureDSP_types.h"

extern const int32_t pow2_table[];

/* polynomial coefficients for 2^x, in range -1...0 */
extern const int32_t pow2poly[];

#endif /* INTEGRIT_VEC_LOG_TABLE_H */
