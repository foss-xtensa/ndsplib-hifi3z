
/*
    tables for expf(x) approximation
*/
#ifndef EXPFTBL_H__
#define EXPFTBL_H__

#include "NatureDSP_types.h"
#include "common.h"

/* 
   polynomial coefficients for 2^x in range 0...1

   derived by MATLAB code:
   order=6;
   x=(0:pow2(1,-16):1);
   y=2.^x;
   p=polyfit(x,y,6);
   p(order+1)=1;
   p(order)=p(order)-(sum(p)-2);
*/
externC const int32_t expftbl_Q30[8]; 
externC const union ufloat32uint32 expfminmax[2];  /* minimum and maximum arguments of expf() input */
externC const int32_t invln2_Q30; /* 1/ln(2), Q30 */

#endif /* EXPFTBL_H__ */
