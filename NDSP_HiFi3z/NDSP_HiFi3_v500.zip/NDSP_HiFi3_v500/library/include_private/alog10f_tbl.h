
/*
    tables for alog10f(x) approximation
*/
#ifndef ALOG10FTBL_H__
#define ALOG10FTBL_H__

#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 alog10fminmax[2];  /* minimum and maximum arguments of alog10f() input */
externC const int32_t invlog10_2_Q29; /* 1/log10(2), Q29 */

#endif /* ALOG10FTBL_H__ */
