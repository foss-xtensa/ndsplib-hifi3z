
#ifndef INTEGRIT_SCL_SINE_TABLE32_H
#define INTEGRIT_SCL_SINE_TABLE32_H
#include "NatureDSP_types.h"

extern const int32_t sine_table32[];

#endif /* INTEGRIT_SCL_SINE_TABLE_H */
