/*
	NaN values for double precision routines
*/

#ifndef __NAN_TBL_H
#define __NAN_TBL_H

/* Portable data types. */
#include "NatureDSP_types.h"
/* Common utility macros. */
#include "common.h"

externC const union ufloat64uint64 sNaN;       /* Signalling NaN          */
externC const union ufloat64uint64 qNaN;       /* Quiet NaN               */
externC const union ufloat64uint64 minus_sNaN; /* Negative Signalling NaN */
externC const union ufloat64uint64 minus_qNaN; /* Negative Quiet NaN      */

#endif /* __NAN_TBL_H */
