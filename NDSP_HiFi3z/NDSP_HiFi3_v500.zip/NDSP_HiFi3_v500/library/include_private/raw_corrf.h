#ifndef RAW_CORRF__
#define RAW_CORRF__
/*
    NatureDSP Signal Processing Library. FIR part
    Real data circular convolution/correlation, floating point, helper file
    IntegrIT, 2006-2017
*/

/* Portable data types. */
#include "NatureDSP_types.h"

/*-------------------------------------------
    raw linear correlation: 
    Input:
    x,y
    Output:
    z
    Restrictions:
    x - aligned on 8 byte boundary
    N>0 && M>0
    N>=M-1
-------------------------------------------*/
void raw_corrf(
                      float32_t  * restrict r,
                const float32_t  * restrict x,
                const float32_t  * restrict y,
                int N, int M );

#endif
