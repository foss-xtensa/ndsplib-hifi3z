
/*
    pi constants for single precision routines
*/
#ifndef PIF_H__
#define PIF_H__

#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 pif ; /* pi */
externC const union ufloat32uint32 pi2f; /* pi/2 */
externC const union ufloat32uint32 pi4f; /* pi/4 */
externC const union ufloat32uint32  pi2m1f;  /* pi/2-1 */

#endif /* PIF_H__ */
