
/*
    1/(2*pi) constant
*/
#ifndef INV2PIF_H__
#define INV2PIF_H__

#include "NatureDSP_types.h"
#include "common.h"

externC const int64_t inv2pif_Q53; /* 1/(2pi) in Q53 */

externC const union ufloat32uint32 inv4pif; /* 4/pi */
externC const union ufloat32uint32 inv2pif; /* 2/pi */
#endif /* INV2PIF_H__ */
