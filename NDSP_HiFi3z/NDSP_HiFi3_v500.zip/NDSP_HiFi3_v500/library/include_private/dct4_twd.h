/*
    NatureDSP Signal Processing Library. FFT part
    DCT-IV twiddles
    Integrit, 2006-2011
*/
#ifndef DCT4_TWD__
#define DCT4_TWD__
#include "NatureDSP_Signal_fft.h"
#include "common.h"

/* DCT-IV twiddles */
typedef struct
{
    int   N;                        /* DCT-IV size                                                     */
    const complex_fract16* split;   /* split part twiddles: exp(-j*pi*[(1:2:N/2) (1:2:N/2)+N]/(4*N))   */
    const complex_fract16* dct3;    /* DCT-III twiddles: exp(j*pi(1:N/4)/N                             */
    const complex_fract16* rfft;    /* real FFT split phase: exp(pi*j(1:N/8)/(N/2)                     */
    const complex_fract16* fft;     /* FFT twddles exp(-j*pi *[1;2;3]*(0:N/4-1)/(N/4)                  */
}
tdct4_twd_fr16;

typedef struct
{
    int   N;                        /* DCT-IV size                                                     */
    const complex_fract32* split;   /* split part twiddles: exp(-j*pi*[(1:2:N/2) (1:2:N/2)+N]/(4*N))   */
    const complex_fract32* dct3;    /* DCT-III twiddles: exp(j*pi*(1:N/4)/N)                           */
    const complex_fract32* rfft;    /* real FFT split phase: exp(j*pi*(1:N/8-1)/(N/4))                 */
    const complex_fract32* fft;     /* FFT twddles exp(-j*pi*[1;2;3]*(0:N/4-1))/(N/4)                  */
}
tdct4_twd_fr32;

#endif
