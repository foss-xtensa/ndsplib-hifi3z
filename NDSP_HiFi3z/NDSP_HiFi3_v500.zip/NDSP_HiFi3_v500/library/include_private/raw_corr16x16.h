#ifndef RAW_CORR16X16_H__
#define RAW_CORR16X16_H__
#include "NatureDSP_types.h"

/*-----------------------------------------------------
    raw correlation:
    Input:
    x[N+M-1] padded with extra 3 zeroes
    y[M]
    Output:
    r[N]
    restriction:
    M should be a multiple of 4 and >0
-----------------------------------------------------*/
void raw_corr16x16(int16_t * r, const int16_t * restrict x, const int16_t * restrict y, int N, int M);

#endif
