
/*
    tables for lognf(x) approximation
*/
#ifndef LOGNF_TBL_H__
#define LOGNF_TBL_H__
#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 ALIGN(8) lognf_tbl[];
externC const union ufloat32uint32 ln2;
#endif /* LOGNF_TBL_H__ */
