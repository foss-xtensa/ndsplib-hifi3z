
/*
    tables for sin(pi/2*x) approximation
*/
#ifndef SINFTBL_H__
#define SINFTBL_H__

#include "NatureDSP_types.h"
#include "common.h"

#define SINNCOSF_ALG 0 /* 0 - 2 ULP, 1 - 1 ULP */

externC const union ufloat32uint32 sinf_maxval; /* domain ranges - zero outside */

/* pi/4 represented as a sum of exacly represented numbers.
    derived from hex value of pi: 3.243F6A8885A308D313198A2E037073
*/
externC const union ufloat64uint64 ALIGN(8) pi4fc[];

/* 
   polynomial coefficients for sin(x)/x, [-pi/4...pi/4]
   derived by MATLAB code:
   s=pow2(1,-16); x=(s:s:pi/4); x=[-x(end:-1:1) x];
   y=sin(x)./x;
   p=polyfit(x,y,6); p=p(1:2:end); p(end)=[];
*/
externC const union ufloat32uint32 ALIGN(8) polysinf_tbl[];

/* 
   polynomial coefficients for cos(x), [-pi/4...pi/4]
   derived by MATLAB code:
   s=pow2(1,-16); x=(s:s:pi/4); x=[-x(end:-1:1) x];
   y=cos(x);
   p=polyfit(x,y,6); p=p(1:2:end); p(end)=[];
*/
externC const union ufloat32uint32 ALIGN(8) polycosf_tbl[];

#endif /* SINFTBL_H__ */
