
/*
    sqrt(2) and sqrt(0.5) constants for single precision routines
*/
#ifndef SQRT2F_H__
#define SQRT2F_H__

#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 sqrt2f  ; /* sqrt(2)   */
externC const union ufloat32uint32 sqrt0_5f; /* sqrt(0.5) */

#endif /* SQRT2F_H__ */
