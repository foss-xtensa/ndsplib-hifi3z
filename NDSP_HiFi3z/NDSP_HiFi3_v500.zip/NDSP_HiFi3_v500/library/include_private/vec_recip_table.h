
#ifndef INTEGRIT_VEC_RECIP_TABLE_H
#define INTEGRIT_VEC_RECIP_TABLE_H
#include "NatureDSP_types.h"

extern const int16_t recip_table[];

#endif /* INTEGRIT_VEC_RECIP_TABLE_H */
