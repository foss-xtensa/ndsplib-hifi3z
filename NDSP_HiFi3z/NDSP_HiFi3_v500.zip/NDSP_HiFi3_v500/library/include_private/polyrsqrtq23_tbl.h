
#ifndef INTEGRIT_SCL_POLYRSQRTQ23_TABLE_H
#define INTEGRIT_SCL_POLYRSQRTQ23_TABLE_H
#include "NatureDSP_types.h"

extern const int32_t polyrsqrtq23[];

#endif /* INTEGRIT_SCL_POLYRSQRTQ23_TABLE_H */
