
/*
    tables for alog2f(x) approximation
*/
#ifndef ALOG2FTBL_H__
#define ALOG2FTBL_H__

#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 alog2fminmax[2];  /* minimum and maximum arguments of alog2f() input */

#endif /* ALOG2FTBL_H__ */
