#ifndef RAW_CORR32X32_H__
#define RAW_CORR32X32_H__
#include "NatureDSP_types.h"

/*-----------------------------------------------------
    raw correlation:
    Input:
    x[N+M-1] padded with extra 3 zeroes
    y[M]
    Output:
    r[N]
    restriction:
    M should be a multiple of 2 and >0
-----------------------------------------------------*/
void raw_corr32x32(int32_t* r, const int32_t* restrict x, const int32_t* restrict y,int N, int M);

#endif
