#ifndef CXFIRF_H__
#define CXFIRF_H__
/*
  NatureDSP Signal Processing Library. FIR part
    Complex block FIR filter, floating point
  IntegrIT, 2006-2017
*/

/* Portable data types. */
#include "NatureDSP_types.h"

/* Filter instance structure. */
typedef struct tag_cxfirf_t
{
  int                   M; /* Filter length                   */
  const complex_float * h; /* Filter coefficients             */
        complex_float * d; /* Delay line of length M          */
        complex_float * p; /* Pointer into the delay line     */
} cxfirf_t;

#endif /* CXFIRF_H__ */
