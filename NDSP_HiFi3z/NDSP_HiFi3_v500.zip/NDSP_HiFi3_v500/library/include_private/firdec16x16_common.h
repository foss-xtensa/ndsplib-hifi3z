
#ifndef _FIRDEC16X16_COMMON_H_
#define _FIRDEC16X16_COMMON_H_

/* Portable data types. */
#include "NatureDSP_types.h"
/* Common utility and macros declarations. */
#include "common.h"

/*-----------------------------------------------------------------------------
 * Data processing function of a particular decimating filter. Stores a
 * block of input samples to the circular delay line buffer and computes
 * decimating FIR filter's response.
 * Input:
 *   delayLine - circular delay line buffer start address
 *   delayLen  - Delay line buffer length
 *   wrIx    - next position in the buffer to be filled with an input sample
 *   x[N*D]  - input samples
 *   h[]     - decimating FIR filter coefficients, array layout varies
 * Output:
 *   y[N]    - output samples
 *   retval  - updated index of the oldest sample
 * Notes and restrictions:
 *   1. Most of data processing functions feature a single, hard-coded 
 *      decimation factor, so they expect a determined value for parameter D.
 *   2. All pointers with the exception of y[N] must be aligned on an 8-bytes
 *      boundary.
 *   3. N - must be a multiple of 4.
 *   4. M - must be a multiple of 4. 
 -----------------------------------------------------------------------------*/

typedef int (proc_fxn_t)( int16_t * restrict y,
                          int16_t * delayLine,
                          int       delayLen,
                    const int16_t * restrict x,
                    const int16_t * restrict h,
                          int wrIx, int D, int N, int M );


proc_fxn_t fir16x16_D2_proc;
proc_fxn_t fir16x16_D3_proc;
proc_fxn_t fir16x16_D4_proc;
proc_fxn_t fir16x16_DX_proc;


#endif
