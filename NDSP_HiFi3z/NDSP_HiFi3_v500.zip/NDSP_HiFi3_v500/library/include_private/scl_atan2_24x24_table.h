
#ifndef INTEGRIT_SCL_ATAN2_24X24_TABLE_H
#define INTEGRIT_SCL_ATAN2_24X24_TABLE_H
#include "NatureDSP_types.h"

extern const f24 polyatan24x24q23[];

#endif /* INTEGRIT_SCL_ATAN2_24X24_TABLE_H */
