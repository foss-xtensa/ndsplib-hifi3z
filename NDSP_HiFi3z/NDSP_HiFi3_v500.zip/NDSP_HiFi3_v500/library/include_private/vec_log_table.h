
#ifndef INTEGRIT_VEC_LOG_TABLE_H
#define INTEGRIT_VEC_LOG_TABLE_H
#include "NatureDSP_types.h"

extern const int32_t log2_table[];

#endif /* INTEGRIT_VEC_LOG_TABLE_H */
