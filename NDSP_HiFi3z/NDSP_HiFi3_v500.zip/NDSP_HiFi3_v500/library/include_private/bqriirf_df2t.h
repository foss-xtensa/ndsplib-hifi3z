#ifndef BQRIIR_DF2T_H__
#define BQRIIR_DF2T_H__

/* Filter instance structure. */
typedef struct 
{
  int               M;  /* Number of biquads         */
  float32_t      * cf; /* 5*M filter coefficients   */
  int16_t        gain; /* total gain                */
  float32_t      * st; /* 3*M   delay elements      */
} bqriirf_df2t_t;

#endif /* BQRIIR_DF2T_H__ */
