
/*
    tables for log2f(x) approximation
*/
#ifndef LOG2F_TBL_H__
#define LOG2F_TBL_H__
#include "NatureDSP_types.h"
#include "common.h"

externC const union ufloat32uint32 ALIGN(8) log2f_tbl[];

#endif /* LOG2F_TBL_H__ */
