#ifndef BQCIIR_DF1_H__
#define BQCIIR_DF1_H__
/* Portable data types. */
#include "NatureDSP_types.h"

/* Filter instance structure. */
typedef struct 
{
  int               M;  /* Number of biquads         */
  float32_t      * cf; /* 5*M filter coefficients   */
  int16_t        gain; /* total gain                */
  complex_float  * st; /* 4*M   delay elements      */
} bqciirf_df1_t;

#endif /* BQCIIR_DF1_H__ */
