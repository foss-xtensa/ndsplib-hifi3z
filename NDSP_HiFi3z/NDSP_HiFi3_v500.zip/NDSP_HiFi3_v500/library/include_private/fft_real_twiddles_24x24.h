/*
    twiddle factors for 24x24 real fwd/rev FFT transforms
*/
#ifndef FFT_REAL_TWIDDLES_24x24_H___
#define FFT_REAL_TWIDDLES_24x24_H___
#include "common.h"

/*
    GENERAL NOTE:
    MAX_RFFT_PWR controls the maximum avaliable size of real FFT transforms
    It may be reconfigured to save total amount of memory needed for storing the tables

    MAX_RFFT_PWR    Maximum real FFT size
    13              8192
    12              4096
    11              2048
    10              1024
     9               512
     8               256
     7               128
*/

#define MAX_RFFT_PWR 13
#define MAX_RFFT_LEN (1<<MAX_RFFT_PWR)

extern const int32_t twiddleSplit24x24[MAX_RFFT_LEN/2];

#endif
