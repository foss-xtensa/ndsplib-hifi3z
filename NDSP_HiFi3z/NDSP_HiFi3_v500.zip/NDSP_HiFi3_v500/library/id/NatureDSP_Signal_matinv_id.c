/*
 * NatureDSP_Signal Library API
 * Matrix Decomposition and Inversion Functions
 * Annotations
 */
#include "NatureDSP_types.h"
#include "NatureDSP_Signal_matinv.h"
#include "common.h"


ANNOTATE_FUN(mtx_inv2x2f, "Matrix inversion (floating point data)");
ANNOTATE_FUN(mtx_inv3x3f, "Matrix inversion (floating point data)");
ANNOTATE_FUN(mtx_inv4x4f, "Matrix inversion (floating point data)");
