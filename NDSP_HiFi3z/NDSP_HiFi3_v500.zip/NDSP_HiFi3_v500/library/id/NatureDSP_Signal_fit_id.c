/*
 * NatureDSP_Signal Library API
 * Fitting and Interpolation Routines
 * Annotations
 */
#include "NatureDSP_types.h"
#include "NatureDSP_Signal_fit.h"
#include "common.h"

ANNOTATE_FUN(vec_poly4_24x24, "Polynomial approximation (24-bit data)");
ANNOTATE_FUN(vec_poly8_24x24, "Polynomial approximation (24-bit data)");
ANNOTATE_FUN(vec_poly4_32x32, "Polynomial approximation (32-bit data)");
ANNOTATE_FUN(vec_poly8_32x32, "Polynomial approximation (32-bit data)");
ANNOTATE_FUN(vec_poly4f,      "Polynomial approximation (floating point data)");
ANNOTATE_FUN(vec_poly8f,      "Polynomial approximation (floating point data)");
